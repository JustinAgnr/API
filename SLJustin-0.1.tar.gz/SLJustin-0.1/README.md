
The package aims to realise an OLS for question2 of the test
